#!/bin/bash
C=/${0}
C=${C%/*}
exec "${C:-.}"/KeychainViewer